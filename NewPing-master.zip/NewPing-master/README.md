NewPing Library (Ultrasonic Sensors)

Written by Tim Eckel

https://code.google.com/p/arduino-new-ping/

Modified for Teensy 3.0 & 3.1

https://github.com/PaulStoffregen/NewPing

http://forum.pjrc.com/threads/25907-Multiple-HCSR-04-Ultrasonic-sensors-on-teensy-3

![Photo](https://raw.githubusercontent.com/PaulStoffregen/NewPing/master/extras/NewPing_photo.jpg)

![Screenshot](https://raw.githubusercontent.com/PaulStoffregen/NewPing/master/extras/NewPing_screenshot.png)


