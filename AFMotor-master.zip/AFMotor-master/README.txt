This liberary includes the codes for the AF motor to move randomly so as to form a base for the swarm bot should move and avoid obstacles in it's way. 
Download the repository and download the new ping library of ultrasonic sensor from https://bitbucket.org/teckel12/arduino-new-ping/downloads/.
